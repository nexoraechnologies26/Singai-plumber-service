# SINGAI SERVICES – Plumber Registration Website

Flask + SQLite அடிப்படையிலான தமிழ்/ஆங்கில Plumber தகவல் சேகரிப்பு website.

## அம்சங்கள்
- Plumber பெயர், மொபைல் எண், முகவரி, பகுதி சேகரிப்பு
- வழங்கும் பிளம்பிங் சேவைகள், அனுபவம், வேலை நேரம், கூடுதல் குறிப்புகள்
- SQLite database-ல் தகவல் சேமிப்பு
- Admin login மூலம் பதிவுகளைப் பார்வையிடுதல்
- CSV-ஆக பதிவுகளைப் பதிவிறக்குதல்
- தேவையற்ற பதிவுகளை Admin நீக்குதல்
- Mobile-friendly responsive design

## Windows-ல் இயக்குவது
1. Python 3.10 அல்லது அதற்கு மேல் நிறுவவும்.
2. ZIP-ஐ extract செய்யவும்.
3. அந்த folder-ல் Command Prompt திறக்கவும்.
4. கீழே உள்ள கட்டளைகளை இயக்கவும்:

```bash
py -m venv venv
venv\\Scripts\\activate
python -m pip install -r requirements.txt
python app.py
```

5. Browser-ல் `http://127.0.0.1:5000` திறக்கவும்.

## Admin Login (முதல் local demo)
- Username: `admin`
- Password: `ChangeMe123!`

## முக்கிய பாதுகாப்பு குறிப்பு
இது local/demo starter project. இணையத்தில் deploy செய்வதற்கு முன் `.env.example`-ஐப் பயன்படுத்தி `SECRET_KEY`, `ADMIN_USER`, `ADMIN_PASSWORD` environment variables அமைக்கவும். Default password-ஐ மாற்றவும்; HTTPS மற்றும் பாதுகாப்பான hosting பயன்படுத்தவும். `app.py`-ல் உள்ள Admin password environment variable-லிருந்து வாசிக்கப்படுகிறது.

## Database
`plumbers.db` தானாக உருவாகும். அதில் plumber பதிவுகள் சேமிக்கப்படும்.


## புதிய வசதிகள் – Plumber ID Card & Experience Certificate
- Admin Dashboard-ல் ஒவ்வொரு பதிவுக்கும் ID Card பொத்தான் உள்ளது.
- SINGAI-P00001 போன்ற தனித்துவ ID தானாக உருவாகும்.
- Print / Save as PDF மூலம் ID Card அச்சிடலாம் அல்லது PDF ஆக சேமிக்கலாம்.
- பணி அனுபவச் சான்றிதழ் விருப்பத்தேர்வு மட்டுமே; பதிவேற்றாவிட்டாலும் பதிவு செய்யலாம்.
- PDF/JPG/PNG, அதிகபட்சம் 5 MB. சான்றிதழை Admin மட்டுமே பார்க்க முடியும்.
- Admin verification முடிந்த பிறகே ID Card-ஐ அதிகாரப்பூர்வமாக வழங்கவும்.
