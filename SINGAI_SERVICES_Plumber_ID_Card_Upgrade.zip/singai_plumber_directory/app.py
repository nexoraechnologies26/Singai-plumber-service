import os, csv, io, sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, abort, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'plumbers.db')
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-before-deployment')
ADMIN_USER = os.environ.get('ADMIN_USER', 'admin')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'ChangeMe123!')


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS plumbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT NOT NULL,
            area TEXT,
            services TEXT NOT NULL,
            experience TEXT,
            availability TEXT,
            notes TEXT,
            certificate_path TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        columns = [row['name'] for row in con.execute("PRAGMA table_info(plumbers)").fetchall()]
        if 'certificate_path' not in columns:
            con.execute('ALTER TABLE plumbers ADD COLUMN certificate_path TEXT')''')


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return fn(*args, **kwargs)
    return wrapped


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    services_list = ['குழாய் பழுது பார்த்தல்', 'புதிய குழாய் பொருத்துதல்', 'கழிப்பறை பழுது பார்த்தல்', 'வாஷ் பேசின் பொருத்துதல்', 'கீசர் பொருத்துதல் / பழுது பார்த்தல்', 'குழாய் கசிவு சரிசெய்தல்', 'தண்ணீர் தொட்டி சுத்தம் செய்தல்', 'இதர பிளம்பிங் வேலைகள்']
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()
        area = request.form.get('area', '').strip()
        services = request.form.getlist('services')
        experience = request.form.get('experience', '').strip()
        availability = request.form.get('availability', '').strip()
        notes = request.form.get('notes', '').strip()
        certificate = request.files.get('experience_certificate')
        certificate_path = None
        if not name or not phone or not address or not services:
            flash('பெயர், மொபைல் எண், முகவரி மற்றும் சேவை வகையை நிரப்பவும்.', 'error')
            return render_template('register.html', services_list=services_list)
        digits = ''.join(c for c in phone if c.isdigit())
        if len(digits) < 10 or len(digits) > 13:
            flash('சரியான மொபைல் எண்ணை உள்ளிடவும்.', 'error')
            return render_template('register.html', services_list=services_list)
        if certificate and certificate.filename:
            if not allowed_file(certificate.filename):
                flash('சான்றிதழுக்கு PDF, JPG அல்லது PNG கோப்புகளை மட்டும் பதிவேற்றவும்.', 'error')
                return render_template('register.html', services_list=services_list)
            certificate_path = 'certificate_' + os.urandom(8).hex() + '_' + secure_filename(certificate.filename)
            certificate.save(os.path.join(UPLOAD_DIR, certificate_path))
        with db() as con:
            con.execute('''INSERT INTO plumbers (name, phone, address, area, services, experience, availability, notes, certificate_path)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (name, phone, address, area, ', '.join(services), experience, availability, notes, certificate_path))
        return redirect(url_for('success'))
    return render_template('register.html', services_list=services_list)


@app.route('/success')
def success():
    return render_template('success.html')


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form.get('username') == ADMIN_USER and check_password_hash(generate_password_hash(ADMIN_PASSWORD), request.form.get('password', '')):
            session['admin_logged_in'] = True
            return redirect(url_for('dashboard'))
        flash('Login விவரங்கள் தவறாக உள்ளன.', 'error')
    return render_template('login.html')


@app.route('/admin/logout')
def admin_logout():
    session.clear()
    return redirect(url_for('home'))


@app.route('/admin')
@admin_required
def dashboard():
    with db() as con:
        plumbers = con.execute('SELECT * FROM plumbers ORDER BY id DESC').fetchall()
    return render_template('dashboard.html', plumbers=plumbers)



@app.route('/admin/plumber/<int:plumber_id>/id-card')
@admin_required
def plumber_id_card(plumber_id):
    with db() as con:
        plumber = con.execute('SELECT * FROM plumbers WHERE id = ?', (plumber_id,)).fetchone()
    if not plumber:
        abort(404)
    return render_template('id_card.html', plumber=plumber, plumber_code=f"SINGAI-P{plumber['id']:05d}")

@app.route('/admin/certificate/<int:plumber_id>')
@admin_required
def view_certificate(plumber_id):
    with db() as con:
        row = con.execute('SELECT certificate_path FROM plumbers WHERE id = ?', (plumber_id,)).fetchone()
    if not row or not row['certificate_path']:
        abort(404)
    return send_from_directory(UPLOAD_DIR, row['certificate_path'], as_attachment=False)

@app.route('/admin/export.csv')
@admin_required
def export_csv():
    with db() as con:
        rows = con.execute('SELECT id, name, phone, address, area, services, experience, availability, notes, certificate_path, created_at FROM plumbers ORDER BY id DESC').fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'பெயர்', 'மொபைல்', 'முகவரி', 'பகுதி', 'சேவைகள்', 'அனுபவம்', 'கிடைக்கும் நேரம்', 'குறிப்புகள்', 'சான்றிதழ் கோப்பு', 'பதிவு தேதி'])
    for row in rows:
        writer.writerow(list(row))
    return Response('\ufeff' + output.getvalue(), mimetype='text/csv; charset=utf-8', headers={'Content-Disposition': 'attachment; filename=singai_plumbers.csv'})


@app.route('/admin/delete/<int:plumber_id>', methods=['POST'])
@admin_required
def delete_plumber(plumber_id):
    with db() as con:
        con.execute('DELETE FROM plumbers WHERE id = ?', (plumber_id,))
    flash('பதிவு நீக்கப்பட்டது.', 'success')
    return redirect(url_for('dashboard'))


init_db()

if __name__ == '__main__':
    app.run(debug=True)
